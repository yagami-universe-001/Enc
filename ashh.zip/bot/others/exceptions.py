class AlreadyDl(Exception):
    pass


class ArgumentParserError(Exception):
    pass


class OldMessage(Exception):
    pass
